/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: adding.h
 *
 * MATLAB Coder version            : 23.2
 * C/C++ source code generated on  : 10-May-2024 23:33:08
 */

#ifndef ADDING_H
#define ADDING_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern double adding(double x, double y);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for adding.h
 *
 * [EOF]
 */
