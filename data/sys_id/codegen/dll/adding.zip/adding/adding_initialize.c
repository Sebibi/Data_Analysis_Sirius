/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: adding_initialize.c
 *
 * MATLAB Coder version            : 23.2
 * C/C++ source code generated on  : 10-May-2024 23:33:08
 */

/* Include Files */
#include "adding_initialize.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void adding_initialize(void)
{
}

/*
 * File trailer for adding_initialize.c
 *
 * [EOF]
 */
