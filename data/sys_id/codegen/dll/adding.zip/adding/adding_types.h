/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: adding_types.h
 *
 * MATLAB Coder version            : 23.2
 * C/C++ source code generated on  : 10-May-2024 23:33:08
 */

#ifndef ADDING_TYPES_H
#define ADDING_TYPES_H

/* Include Files */
#include "rtwtypes.h"

#endif
/*
 * File trailer for adding_types.h
 *
 * [EOF]
 */
